/* 
 * Created by Timothy Street on 2016.05.02  * 
 * Copyright © 2016 Timothy Street. All rights reserved. * 
 */
$(document).ready(function () { 
    $("#hidden-btn-form\\:challenges-display-btn").click();   
});

$(window).unload(function() {
      alert('Handler for .unload() called.');
});
